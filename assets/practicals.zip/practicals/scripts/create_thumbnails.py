"""Command line tool to create thumbnails of image files."""

import argparse
import sys
import os
from tqdm import tqdm
from PIL import Image 

def main():
	"""
    Application entry point responsible for parsing command line requests
    """

	parser = argparse.ArgumentParser(
            description="""Create thumbnails of image files.""",
            add_help=False
            )

    # required args
	parser.add_argument('--root', type=str,
    help="""root of all participant folders which themselves have images to resize""")

	# parse arguments
	if len(sys.argv) < 2:
		print("No arguments supplied")
		parser.print_help()
		sys.exit(-1)
	
	args = parser.parse_args()
	create_thumbnails(args.root)

def get_part_dir(root):
    return [dir for dir in os.listdir(root)
            if os.path.isdir(os.path.join(root, dir))]

def get_img_files(part_dir): # get all files ending in .jpg, .JPG, .jpeg, .JPEG
	return [file for file in os.listdir(part_dir)
				if file.endswith(('.jpg', '.JPG', '.jpeg', '.JPEG'))]	

	


def create_thumbnails(root):
	"""
	Finds all subdirectories within sources directory,
	creates a medium and thumbnail folder within each subdirectory,
	and creates a thumbnail and medium sized image for each image file in that subdirectory
	and places them into the appropriate folder.
	Thumbnail images are 100x87 pixels and medium are 864x645.
	"""
	participantDirs = get_part_dir(root)
	for participantDir in participantDirs:
		# create thumbnail and medium folders
		thumbnailDir = os.path.join(root, participantDir, 'thumbnail')
		mediumDir = os.path.join(root, participantDir, 'medium')
		if not os.path.exists(thumbnailDir):
			os.makedirs(thumbnailDir)
		if not os.path.exists(mediumDir):
			os.makedirs(mediumDir)

		# create thumbnails and medium images
		imageFiles = get_img_files(os.path.join(root, participantDir))
		for imageFile in tqdm(imageFiles):
			# create thumbnail
			thumbnailFile = os.path.join(thumbnailDir, imageFile)
			# use PIL to create thumbnail
			image = Image.open(os.path.join(root, participantDir, imageFile))
			thumbnail = image.resize((100, 87))
			thumbnail.save(thumbnailFile)

			# create medium
			mediumFile = os.path.join(mediumDir, imageFile)
			# use PIL to create medium
			medium = image.resize((864, 645))
			medium.save(mediumFile)
			
if __name__=="__main__":
	main()