You will copy your accelerometer trace myAcc.csz.gz and camera annotations my-annotations.csv to this directory
